// wp-content/themes/yuewei File
//short for document.getElementById
function $() {
	if (arguments.length == 1) return get$(arguments[0]);
	var elements = [];
	$c(arguments).each(function(el){
		elements.push(get$(el));
	});
	return elements;
}
function get$(el){
	if (typeof el == 'string') el = document.getElementById(el);
	return el;
}

function $c(array){
	var nArray = [];
	for (i=0;el=array[i];i++) nArray.push(el);
	return nArray;
}

// get parameters of the comment form
function getParams(f){
	if(typeof(f)=='string')	f = $(f);
	var p='';
	var fi = f.getElementsByTagName('input');
	for (i=0; i<fi.length; i++ ) {
		e=fi[i];
		if (e.name!='') {
			if (e.type=='select')
				element_value=e.options[e.selectedIndex].value;
			else if (e.type=='checkbox' || e.type=='radio') {
				if (e.checked==false)	continue;	
				element_value=e.value;
			}
			else {
				element_value=e.value;
			}
			p+="&"+e.name+'='+encodeURIComponent(element_value);
		}
	}
	fi = f.getElementsByTagName('textarea');
	for (i=0; i<fi.length; i++)	p+="&"+fi[i].name+"="+encodeURIComponent(fi[i].value);
	p += "&random="+Math.random();
	return p;
}

// move comment form to proper position to reply exist comments.
function moveForm(a) {
	var id		= $('comment_reply_ID'),
		disp	= $('reRoot').style,
		form	= $('commentform'),
		e		= $('comment-'+a);
	var es = $('commentform').getElementsByTagName('*');
	
	form.parentNode.removeChild(form);
	if (a) {
		var c = e.getElementsByTagName('ul')[0];
		if (c)
			e.insertBefore(form, c);
		else
			e.appendChild(form);
	} else {
		$('cmtForm').appendChild(form);
	}
	disp.display = (a ? 'inline' : 'none');
	if (id) id.value = (a ? a : 0);
	return;
}

//the function to get an ajax instance
function getXMLInstant()
{
	var xx;
	if ($("ajax"))$("ajax").style.display="block";
	if (window.XMLHttpRequest) 
	{ // Mozilla, Safari,...
		xx = new XMLHttpRequest();
		if (xx.overrideMimeType) 
		{
			xx.overrideMimeType('text/xml');
		}
	} 
	else if (window.ActiveXObject) { // IE
		try {
			xx = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
			try {
				xx = new ActiveXObject("Microsoft.XMLHTTP");
			} catch (e) {}
		}
	}
	if (!xx) {
		alert('Giving up :( Cannot create an XMLHTTP instance');
		return false;
	}
	
	return xx;
}
//the function to send comment
function AjaxSendComment()
{
   var gi = getXMLInstant(), r = $('comment_reply_ID').value, t, c, now = parseInt(Math.random()*1000);
	
	if (r == 0) {
		t = 'comments';
		c = $(t);
	} else {
		t = 'comment-'+r;
		var u = $(t).getElementsByTagName('ul')[0];
		if (u) {
			c = u;
		} else {
			c = document.createElement('ul');
			$(t).appendChild(c);
		}
	}
	// backup comment in case of Comment fail
	var content = $("comment").value;
	var author = "admin", email="a@b.c";
	var temp = content;
	if($("author"))author = $("author").value;
	if($("email"))email = $("email").value;
	//check the author and content input area is fixed
	if(content == "" || (needemail=="0" && (author == "" || email == ""))) {
		if($("nm")) {
	   	$("nm").style.color="red";
	      if(author =="") $("nm").innerHTML = "name is necessary";
			else if(email=="") $("nm").innerHTML = "email is necessary";
	      else $("nm").innerHTML = "comment can not be empty";
		}
	   return true;
	}
	//add comment to local comment list
	content = content.replace(/\r\n\r\n/g, "</p><p>");
	content = content.replace(/\r\n/g, "<br />");
	content = content.replace(/\n\n/g, "</p><p>");
	content = content.replace(/\n/g, "<br />");
	var dateObj = new Date();
	c.innerHTML = c.innerHTML + "<li id='newComment"+now+"'><div class=\"commenthead\">At "+dateObj.toLocaleString()+", <span class=\"author\">"+ author+ "</span> said: </div><div class=\"body\"><p>"  + content+ "</p></div><div class='meta'>submitting...</div></div></li>";
	
	//the state function of ajax 
	gi.onreadystatechange = function()
    {
        if (gi.readyState == 4) {
            if (gi.status == 200) {
               $('newComment'+now).innerHTML=gi.responseText;
					aCookie = document.cookie.split("; ");
					login("login");
					if($("ajax"))$("ajax").style.display = "none";
					if(gi.responseText.search(/Slow down cowboy/) > -1 || gi.responseText.search(/Duplicate comment detected/) > -1)
						$('comment').value = temp;
            } else {
               alert('Failed to add your comment. ');
					$('comment').value = temp;
            }
        }
    }
	
	//send form by ajax
	var p=getParams("commentform"); // get parameters of form
	gi.open('POST', blogurl+"/wp-content/plugins/ajaxcomment/comments-ajax.php", true);
   gi.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
   gi.setRequestHeader("Content-length", p.length);
   gi.setRequestHeader("Connection", "close");
   gi.send(p);
    
	//after send form, move the comment form to original position.
   moveForm(0);
   $('comment').value = '';
   
   return true;
}
// Get content by AJAX

function ajaxShowPost(u, e, j, s){
	if ("undefined"!=typeof(nowurl) && u==nowurl) {
		window.location.href="#"+j;
		return;
	}
	if ( u.match(/getpost/) )	nowurl=u;
	var g = getXMLInstant();
    	
	if ($(e))	e = $(e); 
	else return;
	
	g.onreadystatechange = function(){
		if (g.readyState == 4) {
      	if (g.status == 200) {
         	e.innerHTML = g.responseText;
				if (j)	window.location.href="#"+j;
				if (s) 	eval(s);
				if($("ajax"))$("ajax").style.display = "none";
			} else {
         	alert('There was a problem with the request.');
         }
		}
	}
    
   g.open('GET', u, true);
   g.send(null);
}

// Retrieve the value of the cookie with the specified name.
var aCookie = document.cookie.split("; ");
function GetCookie(sName, id) {
	// cookies are separated by semicolons
	var something = $(id);
	if (!something) return false;
	for (var i=0; i < aCookie.length; i++) {
		// a name alue pair (a crumb) is separated by an equal sign
		var aCrumb = aCookie[i].split("=");
		if (sName == aCrumb[0]) {
			if (sName=="comment_author_"+md5)
				something.value = unescape(decodeURI(aCrumb[1]));
			else if (something.value)
				something.value = unescape(decodeURI(aCrumb[1]));
			else 
				something.innerHTML = unescape(decodeURI(aCrumb[1]));
			return true;
		}
	}
 	// a cookie with the requested name does not exist
 	return true;
}
function login(id) {
	// cookies are separated by semicolons
	var something = $(id), author = "", url = "http://zhiqiang.org/link/";
	if (!something) return 0;
	for (var i=0; i < aCookie.length; i++) {
		// a name alue pair (a crumb) is separated by an equal sign
		var aCrumb = aCookie[i].split("=");
		var sName = aCrumb[0];
		if (sName=="comment_author_"+md5)
			author = unescape(decodeURI(aCrumb[1]));
		else if (sName=="comment_author_url_"+md5)
			url=unescape(decodeURI(aCrumb[1]));
	}
 	
	if (author)	something.innerHTML = "欢迎回来, <a href='" + url + "'><font color='red'>" + author + "</font></a>";
 	return 0;
}

if (typeof(md5)!="undefined") {
	login("login");
	
	GetCookie("comment_author_"+md5, "author");
	GetCookie("comment_author_"+md5, "authorname");
	GetCookie("comment_author_email_"+md5, "email");
	GetCookie("comment_author_url_"+md5, "url");
}