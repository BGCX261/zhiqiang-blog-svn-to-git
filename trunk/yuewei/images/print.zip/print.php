<?php 
require(dirname(__FILE__).'/wp-blog-header.php');
wp_get_current_user();
auth_redirect();

if (!isset($_REQUEST['p'])) :
	$par = $_SERVER['REQUEST_URI'];
	
	$par = split('\?', $par, 2);
	$par = $par[1];
	$posts = query_posts($par);
elseif (isset($_REQUEST['p'])) :
	$par = $_SERVER['REQUEST_URI'];
	
	$par = split('\?', $par, 2);
	$par = $par[1];
	$posts = query_posts($par);
endif;
?>

<html>
<style>
a{
text-decoration:none;
}
#postlist {
	list-style-type:none;
}
.postmeta {
color:#999999;
font-size:0.9em;
margin:0pt;
}
.red{
color:red;
}
.postentry p{line-height:1.2em;
 text-indent:2em;}
 
 #comments {
list-style-type:none;
margin:1.2em 0pt;
padding:0pt;
}
#comments dd {
-moz-border-radius-bottomleft:5px;
-moz-border-radius-bottomright:5px;
-moz-border-radius-topleft:5px;
-moz-border-radius-topright:5px;
background-color:#FFFFFF;
border-top:1px solid #E8E7D0;
padding:1px 10px;
}
.alt {
background-color:#E9E9E9 !important;
}
.commenttitle {
font-size:1.1em;
margin-bottom:0pt;
}
.commentmeta {
color:#999999;
font-size:0.9em;
margin-top:0pt;
}
.commentlist dd {
border-color:#CED4CA;
border-style:solid;
border-width:1px 2px 2px 1px;
clear:both;
list-style-image:none;
list-style-position:outside;
list-style-type:none;
margin:5px 0pt;
padding:5px 5px 0pt;
}
.commentlist dd.trackback {
border:1px double #EEDDDD;
}
.author, .author a {
font-weight:700;
}
.commentlist .body {
margin:5px 10px 5px 15px;
}
.commentlist .body p {
margin:10px 0pt 0pt;
}
.commentlist dd .gravatar {
border:1px solid #DDDDDD;
float:right;
margin:0pt 0pt 5px 10px;
padding:5px;
}
.commentlist dl {
border:medium none;
margin:7px 0pt 0pt 30px;
padding:0pt;
}
.commentlist {
border:medium none;
margin:0pt;
padding:0pt;
}
.commenthead, .meta {
color:#888888;
font-weight:200;
}
.commenthead a, .meta a {
color:#3366BB;
}
</style>
<head>
	<title>
	<?php
		if (!isset($_REQUEST['p'])) :
			echo "索引";
		elseif (isset($_REQUEST['p'])) :
			foreach ($posts as $post):
				echo $post->post_title;
			endforeach;
		endif;
	?>
	</title>
</head>
<body>
<?php

if (!isset($_REQUEST['p'])) :
	// var_dump($posts);
	// echo $par;
	echo 
 "<dl id='postlist'>";
	foreach ($posts as $post) :
		$permalink = get_permalink($post->ID);
		echo "
	<dd>
		<a href='".get_settings("home")."/print.php?p={$post->ID}'>{$post->post_title}</a>
	</dd>";
	endforeach;
	
	echo "
</dl>";

elseif (isset($_REQUEST['p'])) :
	// var_dump($posts);
	// echo $par;
	
	
?>
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		<h1 class="posttitle" id="post-<?php the_ID(); ?>"><a href="<?php the_permalink() ?>" rel="bookmark" title=""><?php the_title(); ?></a></h1>
			
			<div class="postmeta">
			&copy;<span class="red"><?php the_author() ?></span>, <?php the_time('F j, Y') ?> @ <?php the_time() ?> 
			</div>
			
			<div class="postentry">
				<?php the_content(__('(more...)')); ?>
			</div>
			

			
			
			
			<?php // Do not delete these lines
	if ('comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
		die ('Please do not load this page directly. Thanks!');
	if(!$tablecomments && $wpdb->comments)
		$tablecomments = $wpdb->comments;
	$comments = $wpdb->get_results("SELECT * FROM $tablecomments WHERE comment_post_ID = '$id' AND comment_approved = '1' ORDER BY comment_date");
// You can start editing here
	$GLOBALS['comments_reply'] = array();

	function write_comment(&$c, $deep_id = -1) {
		global $max_level;
		$comments_reply = $GLOBALS['comments_reply'];
		if ($c->comment_type == 'trackback')
			$style = ' class="trackback"';
?>
		<dd id="comment-<?php echo $c->comment_ID ?>" <?php echo $style?>><div class="commenthead">At <?php echo mysql2date('Y.m.d H:i', $c->comment_date);?>, 
			<a name='comment-<?php echo $c->comment_ID ?>'></a>
			<span class="author"><?php echo get_comment_author_link();?></span> said: </div>
	<div class="body">
			<?php comment_text();?>
		</div>
		
			<?php
			global $user_ID, $post;
			get_currentuserinfo();
			if (user_can_edit_post_comments($user_ID, $post->ID) || ($GLOBALS['cmtDepth'] < $max_level))
				
					if ($comments_reply[$c->comment_ID]) {
						$id = $c->comment_ID;
						if($GLOBALS['cmtDepth'] < $max_level )
							echo '<dl>';
		foreach($comments_reply[$id] as $c) {
							$GLOBALS['cmtDepth']++;
							if($GLOBALS['cmtDepth'] == $max_level)
								write_comment($c, $c->comment_ID);
							else
								write_comment($c, $deep_id);
							$GLOBALS['cmtDepth']--;
		}
						if($GLOBALS['cmtDepth'] < $max_level )
							echo '</dl>';
					}
					echo '</dd>';
			?>
<?php
	}
?>
<?php if (false): ?>
<div class="clear"></div>
<h4><?php comments_number('沙发', '板凳', '%条留言' );?></h4>
<dl class="commentlist" id="comments">
	<?php
		if ($comments) :
			foreach ($comments as $c) {
				$GLOBALS['comments_reply'][$c->comment_reply_ID][] = $c;
			}
			$GLOBALS['cmtDepth'] = 0;
			foreach($GLOBALS['comments_reply'][0] as $cmt) {
				$GLOBALS['comment'] = &$cmt;
				write_comment($GLOBALS['comment']);
			}
		else:
		endif;
	?>
</dl>
<?php if ('open' == $post->comment_status) : ?>
<div id="cmtForm">
<?php if ( get_option('comment_registration') && !$user_ID ) : ?>
<p>You must be <a href="<?php echo get_option('siteurl'); ?>/wp-login.php?redirect_to=<?php the_permalink(); ?>">logged in</a> to post a comment.</p>
<?php else : ?>
</div>
<?php endif; // If registration required and not logged in ?>
<?php endif; // if you delete this the sky will fall on your head ?>
<?php endif; // no comments list ?>

			<h4>参与讨论请到<a href="<?php the_permalink() ?>#commentform" rel="bookmark" title="<?php _e('Permanent link to'); ?> <?php the_title(); ?>"><?php the_permalink() ?>#commentform</a>
			</h4>
<?php
	endwhile;
	
	endif;

endif;
?>
</body>
</html>